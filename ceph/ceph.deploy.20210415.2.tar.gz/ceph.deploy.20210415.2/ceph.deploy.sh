#!/bin/bash
echo "........ ceph deploy ............."
echo

if [ ! -f ceph.deploy.conf ]
then
  echo ceph.deploy.conf not found
  exit
fi

. ceph.deploy.conf

  mkdir cephinstall
  cd cephinstall

  ceph-deploy --overwrite-conf install --no-adjust-repos ${cnodes[@]}
  [ $? -ne 0 ] && exit $?

  sleep 50
  #两个网段必须已经存在
  #ceph-deploy new  --public-network 192.168.93.0/24 --cluster-network 192.168.122.0/24  k8s-master01 k8s-master02 k8s-master03
  ceph-deploy --overwrite-conf new ${cnodes[@]}
  [ $? -ne 0 ] && exit $?
  sleep 50

  ceph-deploy --overwrite-conf mon create-initial
  [ $? -ne 0 ] && exit $?
  ceph-deploy --overwrite-conf gatherkeys ${cnodes[@]}
  [ $? -ne 0 ] && exit $?
  sleep 50

  ceph-deploy --overwrite-conf admin ${cnodes[@]}
  [ $? -ne 0 ] && exit $?
  sleep 50

  ceph-deploy --overwrite-conf mgr create ${cnodes[@]}
  [ $? -ne 0 ] && exit $?
  sleep 50

  grep 'mon clock drift' /etc/ceph/ceph.conf || cat >> /etc/ceph/ceph.conf <<EOF
mon_allow_pool_delete = true
mon clock drift allowed = 2
mon clock drift warn backoff = 30
EOF
  cp -f /etc/ceph/ceph.conf ceph.conf

  ceph-deploy --overwrite-conf config push ${cnodes[@]}
  [ $? -ne 0 ] && exit $?

  for(( i=0; i<${#cnodes[@]}; i++))
  do
    cnode=${cnodes[$i]}
    cip=${cips[$i]}
  
    ceph-deploy --overwrite-conf  mon add $cnode
  [ $? -ne 0 ] && exit $?
    ceph-deploy --overwrite-conf  mon add $cnode 
  [ $? -ne 0 ] && exit $?
    ceph-deploy --overwrite-conf  mon add $cnode
  [ $? -ne 0 ] && exit $?
    sleep 30
    systemctl restart ceph-mon.target
  done


