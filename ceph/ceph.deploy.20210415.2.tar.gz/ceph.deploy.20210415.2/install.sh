#!/bin/bash -x
exec &> >(tee /tmp/ceph.log)

mypwd=$(realpath $(pwd))
. ceph.deploy.conf

. ceph.dns.sh
#. update.kernel.sh
#. epel.install.sh

. ceph.init.sh
cd $mypwd
. ceph.deploy.sh
cd $mypwd
. ceph.osd.sh
