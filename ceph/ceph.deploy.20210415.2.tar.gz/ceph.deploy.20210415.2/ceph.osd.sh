#!/bin/bash
echo "........ ceph osd ............."
echo

cdev=/dev/vdb

if [ ! -b $cdev ]
then
  echo $cdev not found
  exit
fi

if [ ! -f ceph.deploy.conf ]
then
  echo ceph.deploy.conf not found
  exit
fi

. ceph.deploy.conf

cd cephinstall
for(( i=0; i<${#cnodes[@]}; i++))
do
  cnode=${cnodes[$i]}
  cip=${cips[$i]}

  ceph-deploy --overwrite-conf osd create --data $cdev $cnode
  ceph osd tree
done
