#!/bin/bash
basename $PWD
