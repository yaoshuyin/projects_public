#!/bin/bash
rpm -ivh http://dl.fedoraproject.org/pub/epel/epel-release-latest-7.noarch.rpm
yum update
yum clean all
yum makecache
yum install epel-release -y
