#!/bin/bash
if [ ! -f ceph.deploy.conf ]
then
  echo ceph.deploy.conf not found
  exit
fi

. ceph.deploy.conf

[ -L /etc/resolv.conf ] && rm -f /etc/resolv.conf

for dns in ${cdns[@]}
do
  grep $dns /etc/resolv.conf || cat 2>/dev/null >>/etc/resolv.conf <<EOF 
nameserver $dns
EOF
done
chattr +i /etc/resolv.conf

for(( i=0; i<${#cnodes[@]}; i++))
do
  cnode=${cnodes[$i]}
  cip=${cips[$i]}
  grep $cnode /etc/hosts || cat >> /etc/hosts <<EOF
$cip $cnode
EOF
done
