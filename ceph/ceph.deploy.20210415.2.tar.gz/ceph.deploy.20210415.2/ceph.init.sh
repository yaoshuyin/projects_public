#!/bin/bash -x
echo "........ ceph init ............."
echo

wget -O /etc/yum.repos.d/CentOS-Base.repo http://mirrors.aliyun.com/repo/Centos-7.repo
wget -O /etc/yum.repos.d/epel.repo http://mirrors.aliyun.com/repo/epel-7.repo
sed -i 's/mirrors.cloud.aliyuncs/mirrors.aliyuncs/g' /etc/yum.repos.d/CentOS-Base.repo
sed -i 's/mirrors.cloud.aliyuncs/mirrors.aliyuncs/g' /etc/yum.repos.d/epel.repo

cat > /etc/yum.repos.d/ceph.repo <<EOF
[ceph]
name=ceph
baseurl=http://mirrors.aliyun.com/ceph/rpm-15.2.7/el7/x86_64/
gpgcheck=0
priority =1

[ceph-noarch]
name=cephnoarch
baseurl=http://mirrors.aliyun.com/ceph/rpm-15.2.7/el7/noarch/
gpgcheck=0
priority =1

[ceph-source]
name=Ceph source packages
baseurl=http://mirrors.aliyun.com/ceph/rpm-15.2.7/el7/SRPMS
gpgcheck=0
priority=1
EOF

yum clean all
yum makecache
yum -y install yum-plugin-priorities yum-utils snappy leveldb gdiskpython-argparse gperftools-libs
yum install -y sshpass python-pip python3-pip ntp ntpdate
pip3 install --upgrade pip
pip install --upgrade pip
pip3 install pecan werkzeug
yum -y install gcc python-setuptools python-devel python3-devel
yum -y install ceph-deploy ceph-common ceph-radosgw

systemctl enable ntpd
systemctl start ntpd

myip=$(ifconfig eth0|grep "inet "|awk '{print $2}')
if [ "$myip" = "${cips[0]}" ]
then
  [ -f ~/.ssh/id_rsa ] || ssh-keygen -t rsa
  [ -f ~/.ssh/authorized_keys ] || cat ~/.ssh/id_rsa.pub >> ~/.ssh/authorized_keys

  chmod 600 ~/.ssh/authorized_keys

  cdir=$PWD
  for(( i=1; i<${#cnodes[@]}; i++))
  do
    cnode=${cnodes[$i]}
    cip=${cips[$i]}
    sshpass -p $cpass scp -o StrictHostKeyChecking=no -r ~/.ssh $0 $cdir root@$cnode:~/

    sshpass -p $cpass ssh -o StrictHostKeyChecking=no $cuser@$cnode "cd $cdir ; chmod +x ceph.dns.sh ceph.init.sh ; ./ceph.dns.sh;  ./ceph.init.sh"
  done
fi
